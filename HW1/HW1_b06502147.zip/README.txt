開發環境：Ubuntu系統下VScode
編譯：使用套件code runner運行程式 或 g++ main.cpp -o main.out生成out檔後執行